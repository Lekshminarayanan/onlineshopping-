package com.Dao;

public interface CategoryDao {
	public void insertCategory(Category category)
	{
		
	}
}
