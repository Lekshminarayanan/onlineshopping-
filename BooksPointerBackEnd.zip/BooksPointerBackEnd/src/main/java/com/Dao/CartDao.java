package com.Dao;

public interface CartDao {

	public void insert(Cart cart);

	
}
