package com.Dao;

public interface SupplierDao {
	public void insertSupplier(Supplier supplier)
	{
		
	}
}
