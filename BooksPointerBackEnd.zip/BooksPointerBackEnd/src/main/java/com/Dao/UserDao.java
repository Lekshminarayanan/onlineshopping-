package com.Dao;

public interface UserDao {
	public void insertUser(User user);
}
