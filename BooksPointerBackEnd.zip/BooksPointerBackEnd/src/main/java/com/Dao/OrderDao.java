package com.Dao;

public interface OrderDao {
	public void insert(Orders order)
	
	{
		
	}
}
